import React from "react";
import "./style.css";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addUser } from "../../actions/userActions";

const Start = () => {
    let navigate = useNavigate(); 
    const validateName = () => {
        socket.connect();
        // if username is not taken...
        navigate("./chatlist");
    }

    const socket = useSelector(({socket}) => socket);
    const dispatch = useDispatch();

    useEffect(() => {
        socket.on("adduser", username => {
            dispatch(addUser(username));
        });
    }, []);

    return (
    <div className="start-container">
    <form onSubmit={validateName}>    
        <label for="username">Username: </label>
        <input name="username" required/>
        <input type="submit" className="submitButton">Continue</input>
    </form>
    </div>
    );  
};

export default Start;