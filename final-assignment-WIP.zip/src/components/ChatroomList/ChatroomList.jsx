import "./style.css";
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addUser } from "../../actions/userActions";
const ChatroomList = () => {   
    const [chatrooms, setChatrooms] = useState([]); 
    return (
        <></>
    );  
};

export default ChatroomList;