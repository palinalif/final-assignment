export const ADD_USER = "add_user";

export const CONNECT_SOCKET = "connect_socket";